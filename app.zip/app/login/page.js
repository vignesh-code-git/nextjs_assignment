// "use client";
// import { useState } from "react";
// import { useRouter } from "next/navigation";

// export default function LoginPage() {
//   const [username, setUsername] = useState("");
//   const [password, setPassword] = useState("");
//   const router = useRouter();

//   const handleLogin = (e) => {
//     e.preventDefault();

//     // Simple login check
//     if (username === "user" && password === "123") {
//       // Set cookie so proxy.js allows access
//       document.cookie = "token=valid; path=/;";

//       router.push("/cart"); // redirect after login
//     } else {
//       alert("Wrong credentials");
//     }
//   };

//   return (
//     <div style={{ padding: "2rem" }}>
//       <h2>Login</h2>

//       <form onSubmit={handleLogin}>
//         <input
//           type="text"
//           placeholder="username"
//           value={username}
//           onChange={(e) => setUsername(e.target.value)}
//         /><br/><br/>
        
//         <input
//           type="password"
//           placeholder="password"
//           value={password}
//           onChange={(e) => setPassword(e.target.value)}
//         /><br/><br/>

//         <button type="submit">Login</button>
//       </form>
//     </div>
//   );
// }



// "use client";
// import { useState } from "react";
// import { useRouter } from "next/navigation";

// export default function LoginPage() {
//   const [username, setUsername] = useState("");
//   const [password, setPassword] = useState("");
//   const router = useRouter();

//   const handleLogin = (e) => {
//     e.preventDefault();

//     // Simple login check
//     if (username === "user" && password === "123") {
//       // Set cookie so proxy.js allows access
//       document.cookie = "token=valid; path=/;";

//       router.push("/cart"); // redirect after login
//     } else {
//       alert("Wrong credentials");
//     }
//   };

//   return (
//     <div style={{ padding: "2rem" }}>
//       <h2>Login</h2>

//       <form onSubmit={handleLogin}>
//         <input
//           type="text"
//           placeholder="username"
//           value={username}
//           onChange={(e) => setUsername(e.target.value)}
//         /><br/><br/>
        
//         <input
//           type="password"
//           placeholder="password"
//           value={password}
//           onChange={(e) => setPassword(e.target.value)}
//         /><br/><br/>

//         <button type="submit">Login</button>
//       </form>
//     </div>
//   );
// }


"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const router = useRouter();

  const handleLogin = (e) => {
    e.preventDefault();

    if (username === "vignesh" && password === "123") {
      // Set cookies for token and username
      document.cookie = "token=valid; path=/;";
      document.cookie = `username=${username}; path=/;`;

      setUsername("");
      setPassword("");
      router.push("/"); // redirect after login
    } else {
      alert("Wrong credentials");
    }
  };

  return (
    <div style={{ padding: "2rem" }}>
      <h2>Login</h2>

      <form onSubmit={handleLogin}>
        <input
          type="text"
          placeholder="username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        /><br/><br/>
        
        <input
          type="password"
          placeholder="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        /><br/><br/>

        <button type="submit">Login</button>
      </form>
    </div>
  );
}
